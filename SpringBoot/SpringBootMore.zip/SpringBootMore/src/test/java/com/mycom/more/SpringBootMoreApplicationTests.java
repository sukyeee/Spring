package com.mycom.more;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
