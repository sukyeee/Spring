package com.mycom.basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
